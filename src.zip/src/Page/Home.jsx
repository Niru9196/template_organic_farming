import Header from "../Component/Header"
import Card from "../Component/Card"

const Home = () => {
  return (
    <>
      <Header />
      <Card />
    </>
  )
}
 
export default Home
